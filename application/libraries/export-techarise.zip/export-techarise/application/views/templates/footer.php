</div>
</div>

<div class="col-sm-12 col-md-4">
    <div class="row box">

        <div class="sidebar">
            <div class="sidebar-padder">

               <h3>Side Bar</h3>	

            </div><!-- close .sidebar-padder -->
        </div><!-- close .sidebar -->
    </div>
</div>
</div>
</div><!-- close .*-inner (main-content) -->
</div><!-- close .container -->
</div><!-- close .main-content -->

<footer id="colophon" class="site-footer" role="contentinfo">
    <div id="footer-info">
        <div class="container">
            <div class="site-info">
                Copyright &copy; 2011 - <?php echo date("Y", time()); ?>  <a href="http://techarise.com/" title="techarise.com">TECHARISE.COM</a>  All rights reserved.
            </div><!-- close .site-info -->
        </div>
    </div>
</footer><!-- close #colophon -->
<script type="text/javascript" src="<?php print HTTP_JS_PATH; ?>jquery.min.js"></script>
<script type="text/javascript" src="<?php print HTTP_JS_PATH; ?>/bootstrap/bootstrap.min.js"></script>
</body>
</html>
